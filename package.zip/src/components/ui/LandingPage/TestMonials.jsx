﻿import React from "react";
import SingleSwiper from "../../../pages/testimonials/SingleSwiper";

function TestMonials({  }) {
  return (
    <div className="container-fluid scroll-to-view">
      <SingleSwiper />
    </div>
  );
}

export default TestMonials;
